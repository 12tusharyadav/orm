package com.smartcontact.main.contrller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.smartcontact.main.model.JwtAuthRequest;
import com.smartcontact.main.model.JwtAuthResponse;
import com.smartcontact.main.servicesjwt.UserDetailsServiceImpl;
import com.smartcontact.main.servicesjwt.JwtTokenHelper;


// generat  token firt time 
@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

	@Autowired
	private UserDetailsServiceImpl userDetailsServiceImpl;
	@Autowired
	private JwtTokenHelper jwtTokenHelper;
	@Autowired
	private AuthenticationManager authenticationManager;
	
	
	@PostMapping("/login" )
	public ResponseEntity<JwtAuthResponse> createToken( JwtAuthRequest request) throws Exception
	{
		System.out.println(request+" ooooooo00000000000");
		
		this.authenticate(request.getUsername(),request.getPassword());
		UserDetails userDetails = this.userDetailsServiceImpl.loadUserByUsername(request.getUsername());
		String token = this.jwtTokenHelper.generateToken(userDetails);
		
		System.out.println("Your token isssssssssssssssssssss"+token);
		JwtAuthResponse response = new JwtAuthResponse();
		response.setToken(token);
		return new ResponseEntity<JwtAuthResponse>(response,HttpStatus.OK);
		
		
	}


	private void authenticate(String username, String password) throws Exception {
		// TODO Auto-generated method stub
		UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(username,password);
		try {
		this.authenticationManager.authenticate(usernamePasswordAuthenticationToken);
		}catch(DisabledException e)
		{
			e.printStackTrace();
			throw new Exception("user is disabled");
		}
		
	}
	
}
