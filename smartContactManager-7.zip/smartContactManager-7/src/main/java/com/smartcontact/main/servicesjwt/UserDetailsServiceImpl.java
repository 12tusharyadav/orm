package com.smartcontact.main.servicesjwt;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.smartcontact.main.config.CustomUserDetail;
import com.smartcontact.main.repository.UserRepository;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	
//	@Override
//	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//		// TODO Auto-generated method stub
//		
//		if(username.equals("durgesh"))
//		{
//			return  new User("durgesh",new BCryptPasswordEncoder().encode("mota"), new ArrayList<>());
//		}
//		else
//		{
//			throw new UsernameNotFoundException("user not found exception");
//		}
//		
//	}
	
	@Autowired
	private UserRepository userRepository;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		
		com.smartcontact.main.model.User user = userRepository.getUserByUserName(username);
		if(user==null)
		{
			throw new UsernameNotFoundException("could not found user");
		}
		
		
		CustomUserDetail customUserDetail = new CustomUserDetail(user);
		return customUserDetail;
	}
	

}
