package com.springresr.main.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springresr.main.model.Book;
import com.springresr.main.repository.BookRepository;

@Service
public class BookService {

	@Autowired
	private BookRepository bookRepository;
	
	public Book createBook(Book book) {
		System.out.println("SAVE...");
		return this.bookRepository.save(book);
	
		
	}

	public Optional<Book> getBook(Integer id) {
	return this.bookRepository.findById(id);
	
		
		
	}

		public List<Book> findAll() {
		
		List<Book> findAll = this.bookRepository.findAll();
		return findAll;
          
		}

		public Book delete(int id) {
	
			
			 this.bookRepository.deleteById(id);
			return null;
			
		}

		public Book update(Book book, int id) {
			
			book.setId(id);
			return this.bookRepository.save(book);
		}

	

		

		
			
			
		

		
		
		
}
