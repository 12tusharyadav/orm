package com.smartcontact.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartContactManager2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
