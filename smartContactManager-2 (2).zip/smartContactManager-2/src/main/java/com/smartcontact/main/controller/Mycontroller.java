package com.smartcontact.main.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.smartcontact.main.model.User;

@Controller
public class Mycontroller {
	
	@RequestMapping("/")
	public String openform(Model model)
	{
		
		model.addAttribute("user", new User());
		return "form";
	}
	
	//handler
	@PostMapping("/register")
	public String procees(@ModelAttribute("user") User user)
	{
		System.out.println(user);
		//model.addAttribute("user", new User());
		return "success";
	}

}
